export default {
  SPLASH: 'splashScreen',
  LOGIN: 'login',
  SIGNUP: 'signup',
};
